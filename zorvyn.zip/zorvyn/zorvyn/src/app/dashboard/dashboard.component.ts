import { Component, AfterViewInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

declare var Chart: any;

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html',
  imports: [FormsModule, CommonModule],
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements AfterViewInit {

  role = "viewer";

  transactions = [
    { date: "2026-04-01", amount: 5000, category: "Salary", type: "income" },
    { date: "2026-04-02", amount: 1000, category: "Food", type: "expense" },
    { date: "2026-04-03", amount: 2000, category: "Shopping", type: "expense" }
  ];

  ngAfterViewInit() {
    this.update();
    this.loadCharts();
  }

  renderTable() {
    return this.transactions;
  }

  calculate() {
    let income = 0, expense = 0;

    this.transactions.forEach(t => {
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    });

    return {
      income,
      expense,
      balance: income - expense
    };
  }

  deleteTx(i: number) {
    this.transactions.splice(i, 1);
  }

  addTransaction() {
    let amount: any = prompt("Enter amount");
    let category: any = prompt("Enter category");
    let type: any = prompt("income/expense");

    this.transactions.push({
      date: new Date().toISOString().split('T')[0],
      amount: Number(amount),
      category,
      type
    });
  }
  allTransactions = [...this.transactions];

  search(event: any) {
    const val = event.target.value.toLowerCase();

    this.transactions = this.allTransactions.filter(t =>
      t.category.toLowerCase().includes(val)
    );
  }
  insights() {
    let max = 0, cat = "";
    let map: any = {};

    this.transactions.forEach(t => {
      if (t.type === "expense") {
        map[t.category] = (map[t.category] || 0) + t.amount;
      }
    });

    for (let k in map) {
      if (map[k] > max) {
        max = map[k];
        cat = k;
      }
    }

    return "Highest spending category: " + cat;
  }

  update() { }

  loadCharts() {
    new Chart(document.getElementById("lineChart"), {
      type: 'line',
      data: {
        labels: ["Jan", "Feb", "Mar", "Apr"],
        datasets: [{
          label: "Balance",
          data: [1000, 2000, 1500, 3000]
        }]
      }
    });

    new Chart(document.getElementById("pieChart"), {
      type: 'pie',
      data: {
        labels: ["Food", "Shopping", "Bills"],
        datasets: [{
          data: [500, 800, 600]
        }]
      }
    });
  }

}
